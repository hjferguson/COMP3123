import './App.css';
import DataEntryForm from './components/form'; 

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <DataEntryForm /> 
      </header>
    </div>
  );
}

export default App;
