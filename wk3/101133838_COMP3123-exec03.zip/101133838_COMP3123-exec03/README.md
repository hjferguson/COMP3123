# Class Exercise node Project

Notes:
-Had to add type: commonjs to package.json. From my understanding, it's because my version of node expects different code, and i needed this instead of type : module, or else it can't run. 
-had to npm install in order to update the packages, packagelock packages out of date. severe vulnerabilities
-added appropriate code to index.js in order to get it to work 
-had to comment out a line at the end which was causing program to crash after responding to request TRICKY!! 😡