//Require isn't working on my system anymore?? This is how I include modules when writing in React.js
const http = require("http");
const employees = require("./Employee.js");

console.log("Lab 03 -  NodeJs");

//Define Server Port
const port = process.env.PORT || 8081;

//Create Web Server using CORE API
const server = http.createServer((req, res) => {
    if (req.method !== 'GET') {
        res.end(`{"error": "${http.STATUS_CODES[405]}"}`);
    } else {
        if (req.url === '/') {
            //TODO - Display message "<h1>Welcome to Lab Exercise 03</h1>"
            const message = "<h1>Welcome to Lab Exercise 03</h1>";
            res.writeHead(200, {'Content-Type': 'text/html'}); //additional head info to give content details
            res.end(message); //actual body of response
        }

        if (req.url === '/employee') {
            //TODO - Display all details for employees in JSON format
            res.writeHead(200, { 'Content-Type': 'application/json'});
            res.end(JSON.stringify(employees));
        }

        if (req.url === '/employee/names') {
            //TODO - Display only all employees {first name + lastname} in Ascending order in JSON Array
            //e.g. [ "Ash Lee", "Mac Mohan", "Pritesh Patel"]
            let employeeNames = employees.map(employee => `${employee.firstName} ${employee.lastName}`);
            employeeNames.sort();
            res.writeHead(200, { 'Content-type' : 'application/json'});
            res.end(JSON.stringify(employeeNames));
        
        }   


        if (req.url === '/employee/totalsalary') {
            //TODO - Display Sum of all employees salary in given JSON format 
            //e.g. { "total_salary" : 100 }  
            const totalSalary = employees.reduce((sum, employee) => sum + employee.salary, 0); //use reduce function from last week
            const result = { total_salary : totalSalary };
            res.writeHead(200, { 'Content-Type' : 'application/json' });
            res.end(JSON.stringify(result));
    }
    
    }
    //res.end(`{"error": "${http.STATUS_CODES[404]}"}`) //this line crashes the code after you respond to GET!!!!!!!!! 😡
});

server.listen(port, () => {
    console.log(`Server listening on port ${port}`);
});